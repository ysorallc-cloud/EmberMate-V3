import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity
} from "react-native";
import { useRouter } from "expo-router";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";

export default function LogTab() {
  const router = useRouter();

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingBottom: 80 }}
    >
      {/* HEADER */}
      <Text style={styles.title}>Log</Text>
      <Text style={styles.subtitle}>
        A simple place to capture how today is going and what happened.
      </Text>

      {/* MAIN CALENDAR / TODAY CARD */}
      <View style={styles.calendarCard}>
        <Text style={styles.calendarTitle}>Today & schedule</Text>
        <Text style={styles.calendarSubtitle}>
          See today at a glance, then log what matters most.
        </Text>

        {/* Simple "this week" strip */}
        <View style={styles.weekRow}>
          {["M", "T", "W", "T", "F", "S", "S"].map((d, idx) => (
            <View
              key={idx}
              style={[styles.dayPill, idx === 2 && styles.dayPillActive]}
            >
              <Text
                style={[
                  styles.dayPillText,
                  idx === 2 && styles.dayPillTextActive
                ]}
              >
                {d}
              </Text>
            </View>
          ))}
        </View>

        {/* Morning / afternoon / evening segments */}
        <View style={styles.periodRow}>
          <View style={styles.periodCard}>
            <Text style={styles.periodLabel}>Morning</Text>
            <Text style={styles.periodText}>Meds & first check-in</Text>
          </View>
          <View style={styles.periodCard}>
            <Text style={styles.periodLabel}>Afternoon</Text>
            <Text style={styles.periodText}>Energy, symptoms, vitals</Text>
          </View>
          <View style={styles.periodCard}>
            <Text style={styles.periodLabel}>Evening</Text>
            <Text style={styles.periodText}>Pain, sleep, wind-down</Text>
          </View>
        </View>

        {/* Upcoming items preview */}
        <View style={styles.upcomingBlock}>
          <Text style={styles.upcomingTitle}>Upcoming</Text>
          <View style={styles.upcomingItem}>
            <View style={styles.upcomingDot} />
            <Text style={styles.upcomingText}>
              Telehealth visit tomorrow at 9:30 AM
            </Text>
          </View>
          <View style={styles.upcomingItem}>
            <View style={styles.upcomingDot} />
            <Text style={styles.upcomingText}>
              Refill check for blood pressure meds next week
            </Text>
          </View>
        </View>

        <TouchableOpacity
          style={styles.calendarButton}
          onPress={() => router.push("/log/calendar")}
        >
          <Text style={styles.calendarButtonText}>Open full calendar</Text>
        </TouchableOpacity>
      </View>

      {/* SECTION: MOOD & SYMPTOMS */}
      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>Mood & symptoms</Text>
        <Text style={styles.sectionSubtitle}>
          Quick check on how your body and emotions feel today.
        </Text>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => router.push("/log/mood")}
        >
          <Ionicons name="happy-outline" size={20} color="#fbbf77" />
          <Text style={styles.actionButtonText}>Log mood</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => router.push("/log/symptoms")}
        >
          <MaterialCommunityIcons
            name="heart-pulse"
            size={20}
            color="#fbbf77"
          />
          <Text style={styles.actionButtonText}>Log symptoms</Text>
        </TouchableOpacity>
      </View>

      {/* SECTION: MEDS */}
      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>Medications</Text>
        <Text style={styles.sectionSubtitle}>
          Record what was taken and when so visits stay clear.
        </Text>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => router.push("/log/meds")}
        >
          <Ionicons name="medkit-outline" size={20} color="#fbbf77" />
          <Text style={styles.actionButtonText}>Log meds</Text>
        </TouchableOpacity>
      </View>

      {/* SECTION: VITALS */}
      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>Vitals</Text>
        <Text style={styles.sectionSubtitle}>
          Keep track of blood pressure, sugar, heart rate and more.
        </Text>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => router.push("/log/vitals")}
        >
          <MaterialCommunityIcons name="gauge" size={20} color="#fbbf77" />
          <Text style={styles.actionButtonText}>Log vitals</Text>
        </TouchableOpacity>
      </View>

      {/* SECTION: BODY & MIND */}
      <View style={styles.sectionCard}>
        <Text style={styles.sectionTitle}>Body & mind</Text>
        <Text style={styles.sectionSubtitle}>
          Capture rest, movement, mindfulness or anything else shaping your day.
        </Text>

        <TouchableOpacity
          style={styles.actionButton}
          onPress={() => router.push("/log/activity")}
        >
          <Ionicons name="walk-outline" size={20} color="#fbbf77" />
          <Text style={styles.actionButtonText}>Log wellness</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#020617"
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    color: "#ffffff",
    marginTop: 24,
    marginLeft: 20
  },
  subtitle: {
    marginTop: 6,
    marginLeft: 20,
    marginRight: 20,
    fontSize: 14,
    color: "#cbd5f5"
  },
  calendarCard: {
    marginTop: 18,
    marginHorizontal: 20,
    borderRadius: 22,
    padding: 16,
    backgroundColor: "#020f1f"
  },
  calendarTitle: {
    fontSize: 18,
    fontWeight: "700",
    color: "#f9fafb"
  },
  calendarSubtitle: {
    marginTop: 4,
    fontSize: 13,
    color: "#9ca3b8"
  },
  weekRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 14
  },
  dayPill: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#1f2937",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#020617"
  },
  dayPillActive: {
    backgroundColor: "#22d3ee",
    borderColor: "#22d3ee"
  },
  dayPillText: {
    color: "#9ca3b8",
    fontSize: 13,
    fontWeight: "600"
  },
  dayPillTextActive: {
    color: "#020617"
  },
  periodRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 16
  },
  periodCard: {
    flex: 1,
    marginHorizontal: 3,
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 8,
    backgroundColor: "#041826"
  },
  periodLabel: {
    fontSize: 12,
    fontWeight: "700",
    color: "#fbbf77"
  },
  periodText: {
    fontSize: 11,
    color: "#cbd5f5",
    marginTop: 2
  },
  upcomingBlock: {
    marginTop: 16,
    padding: 10,
    borderRadius: 14,
    backgroundColor: "#04111f"
  },
  upcomingTitle: {
    fontSize: 13,
    fontWeight: "600",
    color: "#e5e7eb",
    marginBottom: 6
  },
  upcomingItem: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4
  },
  upcomingDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "#22d3ee",
    marginRight: 6
  },
  upcomingText: {
    fontSize: 12,
    color: "#9ca3b8",
    flex: 1
  },
  calendarButton: {
    marginTop: 12,
    alignSelf: "flex-start",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "#22d3ee"
  },
  calendarButtonText: {
    fontSize: 12,
    fontWeight: "700",
    color: "#020617"
  },
  sectionCard: {
    marginTop: 18,
    marginHorizontal: 20,
    borderRadius: 20,
    padding: 16,
    backgroundColor: "#020f1f"
  },
  sectionTitle: {
    fontSize: 17,
    fontWeight: "700",
    color: "#f9fafb"
  },
  sectionSubtitle: {
    fontSize: 13,
    color: "#9ca3b8",
    marginTop: 4,
    marginBottom: 10
  },
  actionButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#041826",
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 12,
    marginTop: 6
  },
  actionButtonText: {
    marginLeft: 10,
    color: "#e5e7eb",
    fontSize: 14,
    fontWeight: "600"
  }
});
