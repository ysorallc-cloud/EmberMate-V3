import React from "react";
import { View, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { Colors } from "../theme/theme-tokens";

type Props = {
  size?: number;
};

export default function CoffeeIcon({ size = 28 }: Props) {
  return (
    <View style={styles.iconWrapper}>
      <Ionicons name="cafe-outline" size={size} color={Colors.ok} />
    </View>
  );
}

const styles = StyleSheet.create({
  iconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: Colors.borderSubtle,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#020617"
  }
});
