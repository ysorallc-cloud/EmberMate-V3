import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

export default function CoffeeSupportSheet({ onClose }) {
  return (
    <View style={styles.sheet}>
      <Text style={styles.title}>More support</Text>

      <Text style={styles.section}>Reflective Questions</Text>
      <Text style={styles.item}>• What part of today hit hardest?</Text>
      <Text style={styles.item}>• Support, space or clarity?</Text>
      <Text style={styles.item}>• Boundary issue or energy issue?</Text>

      <Text style={styles.section}>Communication Templates</Text>
      <Text style={styles.item}>• I need to pause this and revisit later.</Text>
      <Text style={styles.item}>• Today is hitting harder than expected.</Text>
      <Text style={styles.item}>• Can you help with [task]?</Text>

      <Text style={styles.section}>Helpful Articles</Text>
      <Text style={styles.item}>• Reset your nervous system in 90 seconds</Text>
      <Text style={styles.item}>• When everything feels heavy</Text>
      <Text style={styles.item}>• Why energy dips aren’t failures</Text>

      <TouchableOpacity onPress={onClose} style={styles.btn}>
        <Text style={styles.btnText}>Close</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  sheet: {
    position: "absolute",
    bottom: 0,
    width: "100%",
    backgroundColor: "#0f172a",
    padding: 20,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24
  },
  title: { color: "#fff", fontSize: 18, marginBottom: 12 },
  section: { color: "#22D3EE", marginTop: 16, marginBottom: 6, fontWeight: "600" },
  item: { color: "#fff", marginBottom: 4 },
  btn: {
    backgroundColor: "#22D3EE",
    padding: 12,
    marginTop: 20,
    borderRadius: 12
  },
  btnText: { textAlign: "center", color: "#0f172a", fontWeight: "600" }
});
