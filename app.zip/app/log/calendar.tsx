import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  SafeAreaView
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";

type Appointment = {
  id: string;
  date: string; // "YYYY-MM-DD"
  title: string;
  time: string;
};

const MOCK_APPOINTMENTS: Appointment[] = [
  { id: "1", date: "2025-12-04", title: "Telehealth visit", time: "9:30 AM" },
  { id: "2", date: "2025-12-04", title: "Evening meds check", time: "8:00 PM" },
  { id: "3", date: "2025-12-06", title: "PT session", time: "2:00 PM" }
];

function formatDateKey(date: Date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export default function CalendarScreen() {
  const router = useRouter();
  const [currentMonth, setCurrentMonth] = useState(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1);
  });

  const [selectedDate, setSelectedDate] = useState(() => new Date());

  const { weeks, monthLabel } = useMemo(() => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();

    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    const daysInMonth = lastDayOfMonth.getDate();

    const startWeekday = firstDayOfMonth.getDay(); // 0–6

    const cells: (Date | null)[] = [];

    // leading blanks
    for (let i = 0; i < startWeekday; i++) {
      cells.push(null);
    }

    // days of month
    for (let d = 1; d <= daysInMonth; d++) {
      cells.push(new Date(year, month, d));
    }

    // pad to multiple of 7
    while (cells.length % 7 !== 0) {
      cells.push(null);
    }

    const weeks: (Date | null)[][] = [];
    for (let i = 0; i < cells.length; i += 7) {
      weeks.push(cells.slice(i, i + 7));
    }

    const monthLabel = currentMonth.toLocaleString("default", {
      month: "long",
      year: "numeric"
    });

    return { weeks, monthLabel };
  }, [currentMonth]);

  const selectedKey = formatDateKey(selectedDate);

  const dayAppointments = useMemo(() => {
    return MOCK_APPOINTMENTS.filter(a => a.date === selectedKey);
  }, [selectedKey]);

  const changeMonth = (offset: number) => {
    setCurrentMonth(prev => new Date(prev.getFullYear(), prev.getMonth() + offset, 1));
    // keep selected day in the new month if possible
    setSelectedDate(prev => new Date(prev.getFullYear(), prev.getMonth() + offset, prev.getDate()));
  };

  const handleBack = () => {
    router.back();
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Header with back button */}
        <View style={styles.headerRow}>
          <TouchableOpacity onPress={handleBack} style={styles.backButton}>
            <Ionicons name="chevron-back" size={22} color="#22D3EE" />
            <Text style={styles.backText}>Back</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.title}>Calendar</Text>

        {/* Month selector */}
        <View style={styles.monthRow}>
          <TouchableOpacity onPress={() => changeMonth(-1)} style={styles.monthArrow}>
            <Ionicons name="chevron-back" size={20} color="#E5E7EB" />
          </TouchableOpacity>

          <Text style={styles.monthLabel}>{monthLabel}</Text>

          <TouchableOpacity onPress={() => changeMonth(1)} style={styles.monthArrow}>
            <Ionicons name="chevron-forward" size={20} color="#E5E7EB" />
          </TouchableOpacity>
        </View>

        <View style={styles.weekdayRow}>
  {["S", "M", "T", "W", "T", "F", "S"].map((d, index) => (
    <Text key={index} style={styles.weekdayText}>
      {d}
    </Text>
  ))}
</View>


        {/* Month grid */}
        <View style={styles.grid}>
          {weeks.map((week, weekIndex) => (
            <View key={weekIndex} style={styles.weekRow}>
              {week.map((date, idx) => {
                if (!date) {
                  return <View key={idx} style={styles.dayCell} />;
                }
                const key = formatDateKey(date);
                const isSelected = key === selectedKey;
                const hasAppt = MOCK_APPOINTMENTS.some(a => a.date === key);

                return (
                  <TouchableOpacity
                    key={idx}
                    style={[
                      styles.dayCell,
                      isSelected && styles.daySelected,
                    ]}
                    onPress={() => setSelectedDate(date)}
                  >
                    <Text
                      style={[
                        styles.dayText,
                        isSelected && styles.dayTextSelected
                      ]}
                    >
                      {date.getDate()}
                    </Text>
                    {hasAppt && <View style={styles.dot} />}
                  </TouchableOpacity>
                );
              })}
            </View>
          ))}
        </View>

        {/* Appointments list */}
        <View style={styles.appointmentsSection}>
          <Text style={styles.sectionTitle}>Appointments</Text>
          {dayAppointments.length === 0 ? (
            <Text style={styles.emptyText}>No visits this day</Text>
          ) : (
            <FlatList
              data={dayAppointments}
              keyExtractor={item => item.id}
              renderItem={({ item }) => (
                <View style={styles.appointmentCard}>
                  <Text style={styles.appointmentTitle}>{item.title}</Text>
                  <Text style={styles.appointmentTime}>{item.time}</Text>
                </View>
              )}
            />
          )}
        </View>
      </View>
    </SafeAreaView>
  );
}

const CELL_SIZE = 40;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#020617"
  },
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 10,
    backgroundColor: "#020617"
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 4
  },
  backButton: {
    flexDirection: "row",
    alignItems: "center"
  },
  backText: {
    color: "#22D3EE",
    fontSize: 16,
    marginLeft: 2
  },
  title: {
    fontSize: 30,
    fontWeight: "800",
    color: "#F9FAFB",
    marginBottom: 12
  },
  monthRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 8
  },
  monthLabel: {
    fontSize: 18,
    fontWeight: "600",
    color: "#E5E7EB"
  },
  monthArrow: {
    padding: 6,
    borderRadius: 999,
    backgroundColor: "rgba(148,163,184,0.15)"
  },
  weekdayRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 4,
    paddingHorizontal: 4
  },
  weekdayText: {
    flex: 1,
    textAlign: "center",
    fontSize: 12,
    fontWeight: "600",
    color: "#9CA3AF"
  },
  grid: {
    borderRadius: 16,
    paddingVertical: 8,
    paddingHorizontal: 4,
    backgroundColor: "rgba(15,23,42,0.95)",
    marginBottom: 16
  },
  weekRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 6
  },
  dayCell: {
    width: CELL_SIZE,
    height: CELL_SIZE,
    borderRadius: CELL_SIZE / 2,
    justifyContent: "center",
    alignItems: "center"
  },
  daySelected: {
    backgroundColor: "#22D3EE"
  },
  dayText: {
    color: "#E5E7EB",
    fontSize: 14,
    fontWeight: "500"
  },
  dayTextSelected: {
    color: "#020617",
    fontWeight: "700"
  },
  dot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: "#FBBF24",
    marginTop: 2
  },
  appointmentsSection: {
    flex: 1,
    marginTop: 8
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#E5E7EB",
    marginBottom: 8
  },
  emptyText: {
    color: "#6B7280",
    fontSize: 14
  },
  appointmentCard: {
    backgroundColor: "rgba(15,23,42,0.95)",
    borderRadius: 14,
    padding: 12,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: "rgba(148,163,184,0.3)"
  },
  appointmentTitle: {
    color: "#F9FAFB",
    fontSize: 15,
    fontWeight: "600"
  },
  appointmentTime: {
    color: "#9CA3AF",
    fontSize: 13,
    marginTop: 2
  }
});
