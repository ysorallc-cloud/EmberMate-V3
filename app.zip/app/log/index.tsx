// app/log/index.tsx

import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity
} from "react-native";
import { useRouter } from "expo-router";
import { Ionicons } from "@expo/vector-icons";

type LogCategory = "vitals" | "medication" | "mood" | "symptom" | "food" | "note";

type RecentEntryType = "vitals" | "mood" | "symptom" | "food" | "medication" | "note";

type RecentEntry = {
  id: string;
  type: RecentEntryType;
  title: string;
  value?: string;
  subtitle: string;
  timestampLabel: string; // "Today 8:30 AM"
};

type CalendarDay = {
  date: Date;
  label: string; // "30"
  weekday: string; // "S", "M", etc.
};

const QUICK_LOG_ITEMS: { key: LogCategory; label: string; icon: string }[] = [
  { key: "vitals", label: "Vitals", icon: "heart" },
  { key: "medication", label: "Medication", icon: "medkit-outline" },
  { key: "mood", label: "Mood", icon: "happy-outline" },
  { key: "symptom", label: "Symptom", icon: "bandage-outline" },
  { key: "food", label: "Food", icon: "restaurant-outline" },
  { key: "note", label: "Note", icon: "document-text-outline" }
];

// Static mock data for now.
// You can later replace this with data from your store or backend.
const RECENT_ENTRIES: RecentEntry[] = [
  {
    id: "1",
    type: "vitals",
    title: "Blood Pressure",
    value: "118/76",
    subtitle: "Today 8:30 AM",
    timestampLabel: "Today 8:30 AM"
  },
  {
    id: "2",
    type: "mood",
    title: "Mood",
    value: "Good",
    subtitle: "Today 7:45 AM",
    timestampLabel: "Today 7:45 AM"
  },
  {
    id: "3",
    type: "symptom",
    title: "Symptom",
    value: "Mild headache",
    subtitle: "Yesterday 9:00 PM",
    timestampLabel: "Yesterday 9:00 PM"
  },
  {
    id: "4",
    type: "vitals",
    title: "Weight",
    value: "165 lbs",
    subtitle: "Yesterday 7:00 AM",
    timestampLabel: "Yesterday 7:00 AM"
  }
];

const TYPE_COLORS: Record<RecentEntryType, string> = {
  vitals: "#22C55E",
  mood: "#FACC15",
  symptom: "#FB923C",
  food: "#4ADE80",
  medication: "#F97316",
  note: "#38BDF8"
};

function startOfWeek(date: Date): Date {
  const d = new Date(date);
  const day = d.getDay(); // 0 is Sunday
  const diff = d.getDate() - day; // go back to Sunday
  d.setDate(diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

function buildWeek(date: Date): CalendarDay[] {
  const start = startOfWeek(date);
  const weekdays = ["S", "M", "T", "W", "T", "F", "S"];

  const result: CalendarDay[] = [];
  for (let i = 0; i < 7; i++) {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    result.push({
      date: d,
      label: String(d.getDate()),
      weekday: weekdays[i]
    });
  }
  return result;
}

export default function LogScreen() {
  const router = useRouter();
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  const weekDays = useMemo(() => buildWeek(selectedDate), [selectedDate]);

  const isSameDay = (a: Date, b: Date) =>
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate();

  const handleQuickLogPress = (key: LogCategory) => {
    // Adjust routes to match your existing file structure.
    // Example: /log/vitals, /log/mood, etc.
    router.push(`/log/${key}`);
  };

  const handleWeeklySummaryPress = () => {
    router.push("/log/summary");
  };

  return (
    <View style={styles.container}>
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        showsVerticalScrollIndicator={false}
      >
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Log</Text>
          <Text style={styles.subtitle}>Record health and wellness data</Text>
        </View>

        {/* Calendar ribbon */}
        <View style={styles.calendarWrapper}>
          <View style={styles.calendarRow}>
            {weekDays.map((day) => {
              const selected = isSameDay(day.date, selectedDate);
              return (
                <TouchableOpacity
                  key={day.date.toISOString()}
                  style={[
                    styles.calendarItem,
                    selected && styles.calendarItemSelected
                  ]}
                  onPress={() => setSelectedDate(day.date)}
                  activeOpacity={0.9}
                >
                  <Text
                    style={[
                      styles.calendarWeekday,
                      selected && styles.calendarWeekdaySelected
                    ]}
                  >
                    {day.weekday}
                  </Text>
                  <Text
                    style={[
                      styles.calendarDate,
                      selected && styles.calendarDateSelected
                    ]}
                  >
                    {day.label}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Quick Log section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Quick Log</Text>
          <View style={styles.quickGrid}>
            {QUICK_LOG_ITEMS.map((item) => (
              <TouchableOpacity
                key={item.key}
                style={styles.quickCard}
                activeOpacity={0.9}
                onPress={() => handleQuickLogPress(item.key)}
              >
                <View style={styles.quickIconWrapper}>
                  <Ionicons name={item.icon as any} size={24} color="#F97316" />
                </View>
                <Text style={styles.quickLabel}>{item.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Today insights */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today&apos;s Patterns</Text>
          <View style={styles.insightsCard}>
            <View style={styles.insightsRow}>
              <View style={styles.insightsBullet} />
              <Text style={styles.insightsText}>
                Mood has been steady compared to yesterday.
              </Text>
            </View>
            <View style={styles.insightsRow}>
              <View style={styles.insightsBullet} />
              <Text style={styles.insightsText}>
                Energy tends to dip in the morning. A short reset may help.
              </Text>
            </View>
            <View style={styles.insightsRow}>
              <View style={styles.insightsBullet} />
              <Text style={styles.insightsText}>
                Meds are on track. No missed doses flagged.
              </Text>
            </View>
            <View style={styles.insightsRow}>
              <View style={styles.insightsBullet} />
              <Text style={styles.insightsText}>
                Headache has appeared 3 times this week. Worth watching.
              </Text>
            </View>
          </View>
        </View>

        {/* Recent entries */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Recent Entries</Text>
          <View style={styles.entriesList}>
            {RECENT_ENTRIES.map((entry) => {
              const color = TYPE_COLORS[entry.type];
              return (
                <TouchableOpacity
                  key={entry.id}
                  style={styles.entryCard}
                  activeOpacity={0.9}
                  onPress={() => {
                    // Could route to a detail screen if needed
                    // router.push(`/log/entry/${entry.id}`);
                  }}
                >
                  <View style={styles.entryIconWrapper}>
                    <View
                      style={[styles.entryIconDot, { backgroundColor: color }]}
                    />
                    <Ionicons
                      name={getEntryIcon(entry.type)}
                      size={20}
                      color="#E5E7EB"
                    />
                  </View>
                  <View style={styles.entryTextWrapper}>
                    <View style={styles.entryTitleRow}>
                      <Text style={styles.entryTitle}>{entry.title}</Text>
                      {entry.value ? (
                        <Text style={[styles.entryValue, { color }]}>
                          {entry.value}
                        </Text>
                      ) : null}
                    </View>
                    <Text style={styles.entrySubtitle}>{entry.subtitle}</Text>
                  </View>
                  <Ionicons
                    name="chevron-forward"
                    size={18}
                    color="#64748B"
                  />
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        {/* Bottom spacing for button */}
        <View style={{ height: 16 }} />
      </ScrollView>

      {/* Weekly summary footer button */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.summaryButton}
          activeOpacity={0.9}
          onPress={handleWeeklySummaryPress}
        >
          <Ionicons name="stats-chart-outline" size={18} color="#0F172A" />
          <Text style={styles.summaryButtonText}>View Weekly Summary</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function getEntryIcon(type: RecentEntryType): keyof typeof Ionicons.glyphMap {
  switch (type) {
    case "vitals":
      return "heart-outline";
    case "mood":
      return "happy-outline";
    case "symptom":
      return "bandage-outline";
    case "food":
      return "restaurant-outline";
    case "medication":
      return "medkit-outline";
    case "note":
    default:
      return "document-text-outline";
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#020617"
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 24,
    paddingBottom: 80
  },
  header: {
    marginBottom: 16
  },
  title: {
    fontSize: 28,
    fontWeight: "700",
    color: "#F9FAFB",
    marginBottom: 4
  },
  subtitle: {
    fontSize: 14,
    color: "#94A3B8"
  },
  calendarWrapper: {
    backgroundColor: "#020817",
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: "rgba(148,163,184,0.3)",
    marginBottom: 24
  },
  calendarRow: {
    flexDirection: "row",
    justifyContent: "space-between"
  },
  calendarItem: {
    width: 40,
    alignItems: "center",
    paddingVertical: 6,
    borderRadius: 9999
  },
  calendarItemSelected: {
    backgroundColor: "#22D3EE"
  },
  calendarWeekday: {
    fontSize: 11,
    color: "#64748B",
    marginBottom: 2
  },
  calendarWeekdaySelected: {
    color: "#0F172A",
    fontWeight: "600"
  },
  calendarDate: {
    fontSize: 16,
    fontWeight: "600",
    color: "#E5E7EB"
  },
  calendarDateSelected: {
    color: "#0F172A"
  },
  section: {
    marginBottom: 24
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: "#E5E7EB",
    marginBottom: 12
  },
  quickGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between"
  },
  quickCard: {
    width: "30%",
    aspectRatio: 1,
    backgroundColor: "#020817",
    borderRadius: 18,
    paddingVertical: 10,
    paddingHorizontal: 6,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "rgba(148,163,184,0.35)",
    alignItems: "center",
    justifyContent: "center"
  },
  quickIconWrapper: {
    marginBottom: 8,
    alignItems: "center",
    justifyContent: "center"
  },
  quickLabel: {
    fontSize: 13,
    color: "#E5E7EB",
    textAlign: "center"
  },
  insightsCard: {
    backgroundColor: "#020817",
    borderRadius: 18,
    padding: 14,
    borderWidth: 1,
    borderColor: "rgba(148,163,184,0.35)"
  },
  insightsRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    marginBottom: 6
  },
  insightsBullet: {
    width: 6,
    height: 6,
    borderRadius: 999,
    backgroundColor: "#22D3EE",
    marginRight: 8,
    marginTop: 6
  },
  insightsText: {
    flex: 1,
    fontSize: 13,
    color: "#CBD5F5"
  },
  entriesList: {
    gap: 10
  },
  entryCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#020817",
    borderRadius: 18,
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: "rgba(30,64,175,0.4)",
    marginBottom: 10
  },
  entryIconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 999,
    backgroundColor: "#0B1120",
    alignItems: "center",
    justifyContent: "center",
    marginRight: 10,
    position: "relative"
  },
  entryIconDot: {
    position: "absolute",
    top: 4,
    right: 4,
    width: 7,
    height: 7,
    borderRadius: 999,
    backgroundColor: "#22D3EE"
  },
  entryTextWrapper: {
    flex: 1
  },
  entryTitleRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "baseline",
    marginBottom: 2
  },
  entryTitle: {
    fontSize: 15,
    fontWeight: "600",
    color: "#E5E7EB"
  },
  entryValue: {
    fontSize: 14,
    fontWeight: "500"
  },
  entrySubtitle: {
    fontSize: 12,
    color: "#94A3B8"
  },
  footer: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    paddingBottom: 18,
    paddingTop: 8,
    backgroundColor: "#020617"
  },
  summaryButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 999,
    paddingVertical: 12,
    backgroundColor: "#22D3EE",
    gap: 8
  },
  summaryButtonText: {
    fontSize: 15,
    fontWeight: "600",
    color: "#020617"
  }
});
