// app/log/meds/index.tsx
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput
} from "react-native";
import { useRouter } from "expo-router";

const PRESET_MEDS = [
  "Acetaminophen 500 mg",
  "Ibuprofen 200 mg",
  "Naproxen 220 mg",
  "Aspirin 81 mg",
  "Omeprazole 20 mg",
  "Lisinopril 10 mg",
  "Amlodipine 5 mg",
  "Losartan 50 mg",
  "Metformin 500 mg",
  "Insulin glargine",
  "Atorvastatin 20 mg",
  "Simvastatin 20 mg",
  "Levothyroxine 50 mcg",
  "Sertraline 50 mg",
  "Escitalopram 10 mg",
  "Gabapentin 300 mg",
  "Albuterol inhaler",
  "Fluticasone nasal spray",
  "Prednisone 10 mg",
  "Ondansetron 4 mg",
  "Hydrochlorothiazide 25 mg",
  "Furosemide 20 mg"
];


export default function MedsLogScreen() {
  const router = useRouter();

  const [medList, setMedList] = useState<string[]>(PRESET_MEDS);
  const [selectedMed, setSelectedMed] = useState<string | null>(null);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const [dose, setDose] = useState("");
  const [timeTaken, setTimeTaken] = useState("");

  const [scheduleNote, setScheduleNote] = useState("");
  const [newMedName, setNewMedName] = useState("");
  const [newMedDefaultDose, setNewMedDefaultDose] = useState("");

  const handleSelectMed = (med: string) => {
    setSelectedMed(med);
    setIsDropdownOpen(false);
  };

  const handleAddMedication = () => {
    if (!newMedName.trim()) return;

    const label = newMedDefaultDose.trim()
      ? `${newMedName.trim()} ${newMedDefaultDose.trim()}`
      : newMedName.trim();

    if (!medList.includes(label)) {
      setMedList(prev => [...prev, label]);
    }

    setNewMedName("");
    setNewMedDefaultDose("");
    setSelectedMed(label);
    setIsDropdownOpen(false);
  };

  const handleSave = () => {
    console.log("Med log:", {
      selectedMed,
      dose,
      timeTaken,
      scheduleNote
    });
    router.back();
  };

  const canSave = !!selectedMed && !!dose && !!timeTaken;

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 40 }}>
      {/* HEADER */}
      <Text style={styles.title}>Medications</Text>
      <Text style={styles.subtitle}>
        Quickly log what was taken, when, and how it fits into your usual schedule.
      </Text>

      {/* SECTION 1: MED SELECTION CARD */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Choose medication</Text>
        <Text style={styles.cardHelper}>
          Start with a quick pick. You can add specific meds to your list.
        </Text>

        {/* Dropdown trigger */}
        <TouchableOpacity
          style={styles.dropdownTrigger}
          onPress={() => setIsDropdownOpen(prev => !prev)}
        >
          <Text style={selectedMed ? styles.dropdownText : styles.dropdownPlaceholder}>
            {selectedMed || "Select a medication"}
          </Text>
          <Text style={styles.dropdownChevron}>{isDropdownOpen ? "▲" : "▼"}</Text>
        </TouchableOpacity>

        {/* Dropdown list */}
        {isDropdownOpen && (
          <View style={styles.dropdownList}>
            {medList.map(med => (
              <TouchableOpacity
                key={med}
                style={styles.dropdownItem}
                onPress={() => handleSelectMed(med)}
              >
                <Text style={styles.dropdownItemText}>{med}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {/* Add new med inline */}
        <Text style={styles.sectionLabel}>Add a medication to this list</Text>
        <TextInput
          style={styles.input}
          placeholder="Medication name (e.g., Gabapentin)"
          placeholderTextColor="#7b8a96"
          value={newMedName}
          onChangeText={setNewMedName}
        />
        <View style={{ height: 8 }} />
        <TextInput
          style={styles.input}
          placeholder="Default dose (optional, e.g., 300 mg)"
          placeholderTextColor="#7b8a96"
          value={newMedDefaultDose}
          onChangeText={setNewMedDefaultDose}
        />

        <TouchableOpacity
          style={[
            styles.secondaryButton,
            !newMedName.trim() && styles.secondaryButtonDisabled
          ]}
          onPress={handleAddMedication}
          disabled={!newMedName.trim()}
        >
          <Text style={styles.secondaryButtonText}>Add to quick list</Text>
        </TouchableOpacity>
      </View>

      {/* SECTION 2: DOSE & TIME CARD */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Today&apos;s dose</Text>
        <Text style={styles.cardHelper}>
          Capture what actually happened, not the ideal schedule.
        </Text>

        <Text style={styles.sectionLabel}>Dose taken</Text>
        <TextInput
          style={styles.input}
          placeholder="Example: 1 tablet, 2 capsules"
          placeholderTextColor="#7b8a96"
          value={dose}
          onChangeText={setDose}
        />

        <Text style={styles.sectionLabel}>Time</Text>
        <TextInput
          style={styles.input}
          placeholder="Example: 8:00 AM"
          placeholderTextColor="#7b8a96"
          value={timeTaken}
          onChangeText={setTimeTaken}
        />
      </View>

      {/* SECTION 3: SCHEDULE & REMINDERS CARD */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Schedule & reminders</Text>
        <Text style={styles.cardHelper}>
          Use this to remember usual times or upcoming changes.
        </Text>

        {/* Quick schedule note to support insights */}
        <Text style={styles.sectionLabel}>Usual time / pattern</Text>
        <TextInput
          style={styles.input}
          placeholder="Example: Morning and evening with food"
          placeholderTextColor="#7b8a96"
          value={scheduleNote}
          onChangeText={setScheduleNote}
        />

        {/* Calendar / appointments entry point */}
        <View style={styles.calendarRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.calendarLabel}>Appointments & reminders</Text>
            <Text style={styles.calendarHelper}>
              Open your calendar to review visits, refills, or reminder times.
            </Text>
          </View>
          <TouchableOpacity
            style={styles.calendarButton}
            onPress={() => router.push("/log/calendar")}
          >
            <Text style={styles.calendarButtonText}>Open calendar</Text>
          </TouchableOpacity>
        </View>

        {/* Hint for future bulk import / audio */}
        <Text style={styles.bulkNote}>
          Later, this section can support imports from a spreadsheet or voice notes so
          you do not have to type everything by hand.
        </Text>
      </View>

      {/* SAVE / CANCEL */}
      <TouchableOpacity
        style={[styles.primaryButton, !canSave && styles.disabledButton]}
        onPress={handleSave}
        disabled={!canSave}
      >
        <Text style={styles.primaryButtonText}>Save meds</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.linkButton} onPress={() => router.back()}>
        <Text style={styles.linkText}>Cancel</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#021827",
    paddingHorizontal: 18,
    paddingTop: 28
  },
  title: {
    fontSize: 26,
    fontWeight: "700",
    color: "#ffffff"
  },
  subtitle: {
    marginTop: 6,
    fontSize: 14,
    color: "#cfd8e3",
    marginBottom: 14
  },
  card: {
    backgroundColor: "#0b2533",
    borderRadius: 20,
    padding: 16,
    marginTop: 14
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "700",
    color: "#f9fafb"
  },
  cardHelper: {
    fontSize: 13,
    color: "#9caec0",
    marginTop: 4,
    marginBottom: 10
  },
  sectionLabel: {
    marginTop: 10,
    marginBottom: 4,
    fontSize: 13,
    fontWeight: "600",
    color: "#e5edf5"
  },
  input: {
    backgroundColor: "#02121c",
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 10,
    color: "#ffffff",
    fontSize: 14
  },
  dropdownTrigger: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#02121c",
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 12,
    marginTop: 4
  },
  dropdownText: {
    color: "#f9fafb",
    fontSize: 14
  },
  dropdownPlaceholder: {
    color: "#7b8a96",
    fontSize: 14
  },
  dropdownChevron: {
    color: "#9caec0",
    fontSize: 14
  },
  dropdownList: {
    marginTop: 8,
    backgroundColor: "#02121c",
    borderRadius: 14,
    overflow: "hidden"
  },
  dropdownItem: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: "#0f2937"
  },
  dropdownItemText: {
    color: "#e5edf5",
    fontSize: 14
  },
  secondaryButton: {
    marginTop: 10,
    alignSelf: "flex-start",
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#f0c48a",
    backgroundColor: "#221c13"
  },
  secondaryButtonDisabled: {
    opacity: 0.4
  },
  secondaryButtonText: {
    color: "#f0c48a",
    fontWeight: "600",
    fontSize: 13
  },
  calendarRow: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 16,
    gap: 12
  },
  calendarLabel: {
    fontSize: 13,
    fontWeight: "600",
    color: "#e5edf5"
  },
  calendarHelper: {
    fontSize: 12,
    color: "#9caec0",
    marginTop: 2
  },
  calendarButton: {
    backgroundColor: "#f0c48a",
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 999
  },
  calendarButtonText: {
    color: "#3f2f1d",
    fontSize: 12,
    fontWeight: "700"
  },
  bulkNote: {
    marginTop: 10,
    fontSize: 11,
    color: "#738395"
  },
  primaryButton: {
    marginTop: 20,
    backgroundColor: "#22d3ee",
    paddingVertical: 12,
    borderRadius: 18,
    alignItems: "center"
  },
  disabledButton: {
    opacity: 0.4
  },
  primaryButtonText: {
    color: "#021827",
    fontWeight: "700",
    fontSize: 16
  },
  linkButton: {
    marginTop: 10,
    alignItems: "center"
  },
  linkText: {
    color: "#e5edf5",
    fontSize: 14
  }
});
